%% This code generates the library of all the concentration profiles from a specified range of TK parameters
%% Next, it used k-SVD to learn a smaller dictionary of basis functions from the library
%% Demo is set up with the e_Tofts model; flexible to change to other models. 

clear all; 

dir = pwd;
cd ..;
addpath(genpath('./rocketship_fitting/'))
cd (dir);

% range of the TK parameters 
ktrans =[eps,0.01:0.01:0.8];
ve=[eps,0.01:0.01:0.8];
vp=[eps,0.01:0.01:0.6];

% key parameters
opts.nt=50;
delay=9; % delay frames for contrast injection
tpres=5; % temporal resolution
time=[zeros(1,delay),[1:(opts.nt-delay)]*tpres];
AIF=SAIF_p(time); % Population-based AIF
hct = 0.4;  
AIF = AIF(:)./(1-hct); 
C_AIF=AIF;

tmax = opts.nt*5;          % time range over which to solve model (secs)
tstep = tpres;             % time resolution, secs    
tspan = 1:tstep:tmax;
 
%% generate a library of all the profiles 
o=1; 
library = zeros(length(vp)*length(ktrans)*length(ve),length(tspan)); 

for i=1:length(ktrans)
    i
    for j=1:length(ve)
        for k = 1:length(vp)
            library(o,:) = model_extended_tofts_cfit( ktrans(i),ve(j),vp(k), C_AIF, tspan); %e-Tofts model from rocketship
            o=o+1; 
        end
    end
end
    
toc

fn = 'library_etofts.mat'; 
conc_curves = library ; 
save(fn,'conc_curves','ktrans','ve','vp','C_AIF'); 

%% call k-SVD to learn a smaller dictionary from the library

S=conc_curves;
S(isnan(S))=0; 
[n1 ,n2]=size(S); 
TrainData = reshape(S, n1,n2)'; 


K=100; % number of atoms in the dictionary
[n,~]=size(TrainData);

% Initial dictionary
% ========================================================
DCT=zeros(n,K);
for k=0:1:K-1,
    V=cos([0:1:n-1]'*k*pi/K);
  if k>0, V=V-mean(V); end;
   DCT(:,k+1)=V/norm(V);
end;


l = [3]; % parameter k in k-SVD; choose as 3 for e-Tofts model
param.errorFlag=0;
param.K=K; 
param.numIteration=20; 
param.InitializationMethod='GivenMatrix'; 
param.TrueDictionary=0;
param.Method='KSVD';
param.L=l;  

param.initialDictionary=DCT;
[DicMOD,OutMOD]=TrainDic(TrainData,param);


newMOD=DicMOD*OutMOD.CoefMatrix;
[n1,n2,n3]=size(S);im=S;
newim= reshape(newMOD',n1,n2,n3);

SER=-10*log10( sum(sum(sum(sum(abs(newim-im).^2))))/ sum(sum(sum(sum(abs(im).^2)))));
U=OutMOD.CoefMatrix';
V=DicMOD';
SER_l(l) = SER
fn = sprintf('eTofts_dictionary.mat'); 
save(fn, 'SER_l','U','V'); 
